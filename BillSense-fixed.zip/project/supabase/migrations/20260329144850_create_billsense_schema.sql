/*
  # BillSense Database Schema

  1. New Tables
    - `appliances`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `name` (text) - appliance name
      - `wattage` (integer) - power consumption in watts
      - `daily_hours` (numeric) - hours used per day
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `family_members`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `name` (text) - member name
      - `color` (text) - display color for charts
      - `created_at` (timestamptz)
    
    - `appliance_assignments`
      - `id` (uuid, primary key)
      - `appliance_id` (uuid, references appliances)
      - `member_id` (uuid, references family_members)
      - `percentage` (integer) - usage percentage (0-100)
      - `created_at` (timestamptz)
    
    - `user_settings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users, unique)
      - `electricity_rate` (numeric) - cost per kWh
      - `location` (text) - city for weather data
      - `currency` (text) - currency symbol
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
*/

CREATE TABLE IF NOT EXISTS appliances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  name text NOT NULL,
  wattage integer NOT NULL,
  daily_hours numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE appliances ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own appliances"
  ON appliances FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own appliances"
  ON appliances FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own appliances"
  ON appliances FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own appliances"
  ON appliances FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS family_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  name text NOT NULL,
  color text DEFAULT '#4fc3f7',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE family_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own family members"
  ON family_members FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own family members"
  ON family_members FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own family members"
  ON family_members FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own family members"
  ON family_members FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS appliance_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  appliance_id uuid REFERENCES appliances(id) ON DELETE CASCADE NOT NULL,
  member_id uuid REFERENCES family_members(id) ON DELETE CASCADE NOT NULL,
  percentage integer NOT NULL DEFAULT 100,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_percentage CHECK (percentage >= 0 AND percentage <= 100)
);

ALTER TABLE appliance_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own appliance assignments"
  ON appliance_assignments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM appliances
      WHERE appliances.id = appliance_assignments.appliance_id
      AND appliances.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own appliance assignments"
  ON appliance_assignments FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM appliances
      WHERE appliances.id = appliance_assignments.appliance_id
      AND appliances.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update own appliance assignments"
  ON appliance_assignments FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM appliances
      WHERE appliances.id = appliance_assignments.appliance_id
      AND appliances.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM appliances
      WHERE appliances.id = appliance_assignments.appliance_id
      AND appliances.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own appliance assignments"
  ON appliance_assignments FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM appliances
      WHERE appliances.id = appliance_assignments.appliance_id
      AND appliances.user_id = auth.uid()
    )
  );

CREATE TABLE IF NOT EXISTS user_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users UNIQUE NOT NULL,
  electricity_rate numeric DEFAULT 0.12,
  location text DEFAULT 'New York',
  currency text DEFAULT '$',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own settings"
  ON user_settings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own settings"
  ON user_settings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own settings"
  ON user_settings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own settings"
  ON user_settings FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);