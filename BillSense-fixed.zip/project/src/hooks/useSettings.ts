import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { UserSettings } from '../lib/supabase';

export function useSettings(userId: string | undefined) {
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) {
      setLoading(false);
      return;
    }

    loadSettings();
  }, [userId]);

  const loadSettings = async () => {
    if (!userId) return;

    const { data, error } = await supabase
      .from('user_settings')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (error && error.code !== 'PGRST116') {
      console.error('Error loading settings:', error);
      setLoading(false);
      return;
    }

    if (!data) {
      const { data: newSettings, error: insertError } = await supabase
        .from('user_settings')
        .insert({
          user_id: userId,
          electricity_rate: 0.12,
          location: 'New York',
          currency: '$'
        })
        .select()
        .single();

      if (insertError) {
        console.error('Error creating settings:', insertError);
      } else {
        setSettings(newSettings);
      }
    } else {
      setSettings(data);
    }

    setLoading(false);
  };

  const updateSettings = async (updates: Partial<UserSettings>) => {
    if (!userId || !settings) return;

    const { data, error } = await supabase
      .from('user_settings')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) {
      console.error('Error updating settings:', error);
      return { error };
    }

    setSettings(data);
    return { data };
  };

  return { settings, loading, updateSettings, refreshSettings: loadSettings };
}
