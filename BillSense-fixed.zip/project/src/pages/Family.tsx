import { useEffect, useState } from 'react';
import { Users, Plus, X, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Appliance, FamilyMember, ApplianceAssignment, UserSettings } from '../lib/supabase';

interface FamilyProps {
  userId: string;
  settings: UserSettings | null;
}

const COLORS = ['#4fc3f7', '#7c6af7', '#f48fb1', '#81c784', '#ffd54f', '#ff8a65'];

export function Family({ userId, settings }: FamilyProps) {
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [appliances, setAppliances] = useState<Appliance[]>([]);
  const [assignments, setAssignments] = useState<ApplianceAssignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [showMemberForm, setShowMemberForm] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  const [selectedAppliance, setSelectedAppliance] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, [userId]);

  const loadData = async () => {
    const [membersRes, appliancesRes, assignmentsRes] = await Promise.all([
      supabase.from('family_members').select('*').eq('user_id', userId),
      supabase.from('appliances').select('*').eq('user_id', userId),
      supabase.from('appliance_assignments').select('*')
    ]);

    if (!membersRes.error) setMembers(membersRes.data || []);
    if (!appliancesRes.error) setAppliances(appliancesRes.data || []);
    if (!assignmentsRes.error) setAssignments(assignmentsRes.data || []);

    setLoading(false);
  };

  const addMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim()) return;

    const colorIndex = members.length % COLORS.length;
    const { error } = await supabase.from('family_members').insert({
      user_id: userId,
      name: newMemberName,
      color: COLORS[colorIndex]
    });

    if (!error) {
      setNewMemberName('');
      setShowMemberForm(false);
      loadData();
    }
  };

  const deleteMember = async (id: string) => {
    if (!confirm('Delete this family member?')) return;

    const { error } = await supabase.from('family_members').delete().eq('id', id);
    if (!error) loadData();
  };

  const updateAssignment = async (applianceId: string, memberId: string, percentage: number) => {
    const existing = assignments.find(
      a => a.appliance_id === applianceId && a.member_id === memberId
    );

    if (existing) {
      if (percentage === 0) {
        await supabase.from('appliance_assignments').delete().eq('id', existing.id);
      } else {
        await supabase
          .from('appliance_assignments')
          .update({ percentage })
          .eq('id', existing.id);
      }
    } else if (percentage > 0) {
      await supabase.from('appliance_assignments').insert({
        appliance_id: applianceId,
        member_id: memberId,
        percentage
      });
    }

    loadData();
  };

  const calculateMemberCost = (memberId: string) => {
    if (!settings) return 0;

    return assignments
      .filter(a => a.member_id === memberId)
      .reduce((sum, assignment) => {
        const appliance = appliances.find(app => app.id === assignment.appliance_id);
        if (!appliance) return sum;

        const dailyKwh = (appliance.wattage * appliance.daily_hours) / 1000;
        const monthlyCost = dailyKwh * 30 * settings.electricity_rate;
        return sum + (monthlyCost * assignment.percentage) / 100;
      }, 0);
  };

  const getAssignmentPercentage = (applianceId: string, memberId: string) => {
    const assignment = assignments.find(
      a => a.appliance_id === applianceId && a.member_id === memberId
    );
    return assignment?.percentage || 0;
  };

  const totalBill = appliances.reduce((sum, app) => {
    const dailyKwh = (app.wattage * app.daily_hours) / 1000;
    return sum + dailyKwh * 30 * (settings?.electricity_rate || 0.12);
  }, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Loading...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Family Bill Splitter</h2>
          <p className="text-gray-400">Assign appliances and calculate each person's share</p>
        </div>
        <button
          onClick={() => setShowMemberForm(true)}
          className="bg-[#4fc3f7] text-white px-4 py-2 rounded-lg font-semibold hover:bg-[#3fb3e7] transition-colors flex items-center gap-2"
        >
          <Plus size={20} />
          Add Member
        </button>
      </div>

      {showMemberForm && (
        <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-white">Add Family Member</h3>
            <button
              onClick={() => setShowMemberForm(false)}
              className="text-gray-400 hover:text-white"
            >
              <X size={20} />
            </button>
          </div>

          <form onSubmit={addMember} className="flex gap-4">
            <input
              type="text"
              value={newMemberName}
              onChange={(e) => setNewMemberName(e.target.value)}
              className="flex-1 px-4 py-2 bg-[#060d1f] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#4fc3f7]"
              placeholder="Enter name"
              required
            />
            <button
              type="submit"
              className="bg-[#4fc3f7] text-white px-6 py-2 rounded-lg font-semibold hover:bg-[#3fb3e7] transition-colors"
            >
              Add
            </button>
          </form>
        </div>
      )}

      {members.length === 0 ? (
        <div className="bg-[#0a1628] p-12 rounded-xl border border-gray-800 text-center">
          <Users className="text-gray-600 mx-auto mb-4" size={48} />
          <h3 className="text-xl font-bold text-white mb-2">No Family Members</h3>
          <p className="text-gray-400 mb-4">Add family members to split your electricity bill</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {members.map((member) => {
              const memberCost = calculateMemberCost(member.id);
              const percentage = totalBill > 0 ? (memberCost / totalBill) * 100 : 0;

              return (
                <div
                  key={member.id}
                  className="bg-[#0a1628] p-6 rounded-xl border border-gray-800"
                  style={{ borderColor: member.color + '40' }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-xl"
                        style={{ backgroundColor: member.color }}
                      >
                        {member.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-white">{member.name}</h3>
                        <p className="text-sm text-gray-400">{percentage.toFixed(1)}% of bill</p>
                      </div>
                    </div>
                    <button
                      onClick={() => deleteMember(member.id)}
                      className="text-gray-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>

                  <div className="pt-4 border-t border-gray-700">
                    <div className="text-2xl font-bold" style={{ color: member.color }}>
                      {settings?.currency}{memberCost.toFixed(2)}
                    </div>
                    <div className="text-sm text-gray-500 mt-1">Monthly share</div>
                  </div>
                </div>
              );
            })}
          </div>

          {appliances.length > 0 && (
            <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
              <h3 className="text-xl font-bold text-white mb-4">Appliance Assignments</h3>

              <div className="space-y-4">
                {appliances.map((appliance) => (
                  <div key={appliance.id} className="bg-[#060d1f] p-4 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-white">{appliance.name}</h4>
                        <p className="text-sm text-gray-400">
                          {appliance.wattage}W × {appliance.daily_hours}h/day
                        </p>
                      </div>
                      <div className="text-[#4fc3f7] font-bold">
                        {settings?.currency}
                        {((appliance.wattage * appliance.daily_hours * 30) / 1000 * (settings?.electricity_rate || 0.12)).toFixed(2)}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {members.map((member) => {
                        const percentage = getAssignmentPercentage(appliance.id, member.id);

                        return (
                          <div
                            key={member.id}
                            className="flex items-center gap-3 bg-[#0a1628] p-3 rounded-lg"
                          >
                            <div
                              className="w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold"
                              style={{ backgroundColor: member.color }}
                            >
                              {member.name.charAt(0)}
                            </div>
                            <input
                              type="number"
                              min="0"
                              max="100"
                              value={percentage}
                              onChange={(e) =>
                                updateAssignment(
                                  appliance.id,
                                  member.id,
                                  parseInt(e.target.value) || 0
                                )
                              }
                              className="w-20 px-2 py-1 bg-[#060d1f] border border-gray-700 rounded text-white text-sm focus:outline-none focus:border-[#4fc3f7]"
                            />
                            <span className="text-gray-400 text-sm">%</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
