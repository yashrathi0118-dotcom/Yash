import { useState, useEffect } from 'react';
import { Settings as SettingsIcon, Save } from 'lucide-react';
import type { UserSettings } from '../lib/supabase';

interface SettingsProps {
  settings: UserSettings | null;
  onUpdate: (updates: Partial<UserSettings>) => Promise<any>;
}

export function Settings({ settings, onUpdate }: SettingsProps) {
  const [formData, setFormData] = useState({
    electricity_rate: '',
    location: '',
    currency: ''
  });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (settings) {
      setFormData({
        electricity_rate: settings.electricity_rate.toString(),
        location: settings.location,
        currency: settings.currency
      });
    }
  }, [settings]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage('');

    const { error } = await onUpdate({
      electricity_rate: parseFloat(formData.electricity_rate),
      location: formData.location,
      currency: formData.currency
    });

    setSaving(false);

    if (error) {
      setMessage('Error saving settings');
    } else {
      setMessage('Settings saved successfully!');
      setTimeout(() => setMessage(''), 3000);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Settings</h2>
        <p className="text-gray-400">Customize your BillSense experience</p>
      </div>

      <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800 max-w-2xl">
        <div className="flex items-center gap-3 mb-6">
          <SettingsIcon className="text-[#4fc3f7]" size={24} />
          <h3 className="text-xl font-bold text-white">General Settings</h3>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Electricity Rate (per kWh)
            </label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                {formData.currency}
              </span>
              <input
                type="number"
                step="0.001"
                value={formData.electricity_rate}
                onChange={(e) => setFormData({ ...formData, electricity_rate: e.target.value })}
                className="w-full pl-10 pr-4 py-3 bg-[#060d1f] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#4fc3f7]"
                required
                min="0"
              />
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Check your utility bill for your exact rate. US average is $0.12/kWh
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Location
            </label>
            <input
              type="text"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="w-full px-4 py-3 bg-[#060d1f] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#4fc3f7]"
              placeholder="e.g., New York, London, Tokyo"
              required
            />
            <p className="text-xs text-gray-500 mt-2">
              Used for weather data and predictions
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Currency Symbol
            </label>
            <select
              value={formData.currency}
              onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
              className="w-full px-4 py-3 bg-[#060d1f] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#4fc3f7]"
              required
            >
              <option value="$">$ (USD)</option>
              <option value="€">€ (EUR)</option>
              <option value="£">£ (GBP)</option>
              <option value="¥">¥ (JPY/CNY)</option>
              <option value="₹">₹ (INR)</option>
              <option value="₦">₦ (NGN)</option>
            </select>
          </div>

          {message && (
            <div className={`p-4 rounded-lg ${
              message.includes('Error')
                ? 'bg-red-500/10 border border-red-500 text-red-500'
                : 'bg-green-500/10 border border-green-500 text-green-500'
            }`}>
              {message}
            </div>
          )}

          <button
            type="submit"
            disabled={saving}
            className="w-full bg-[#4fc3f7] text-white py-3 rounded-lg font-semibold hover:bg-[#3fb3e7] transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Save size={20} />
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </form>
      </div>

      <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800 max-w-2xl">
        <h3 className="text-xl font-bold text-white mb-4">About BillSense</h3>
        <div className="space-y-3 text-gray-400">
          <p>
            BillSense is a weather-linked electricity bill predictor that helps you
            understand and optimize your energy usage.
          </p>
          <div className="pt-4 border-t border-gray-700">
            <h4 className="text-white font-semibold mb-2">Features:</h4>
            <ul className="space-y-2 text-sm">
              <li>• Real-time bill estimation based on your appliances</li>
              <li>• Weather impact analysis and predictions</li>
              <li>• Peak hour alerts to optimize usage timing</li>
              <li>• Family bill splitting with appliance assignments</li>
              <li>• Detailed cost breakdown per appliance</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
