import { useEffect, useState } from 'react';
import { DollarSign, TrendingUp, Cloud, Zap } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Appliance, UserSettings } from '../lib/supabase';

interface DashboardProps {
  userId: string;
  settings: UserSettings | null;
}

export function Dashboard({ userId, settings }: DashboardProps) {
  const [appliances, setAppliances] = useState<Appliance[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAppliances();
  }, [userId]);

  const loadAppliances = async () => {
    const { data, error } = await supabase
      .from('appliances')
      .select('*')
      .eq('user_id', userId);

    if (error) {
      console.error('Error loading appliances:', error);
    } else {
      setAppliances(data || []);
    }
    setLoading(false);
  };

  const calculateMonthlyBill = () => {
    if (!settings) return 0;

    const totalDailyKwh = appliances.reduce((sum, app) => {
      return sum + (app.wattage * app.daily_hours) / 1000;
    }, 0);

    const monthlyKwh = totalDailyKwh * 30;
    return monthlyKwh * settings.electricity_rate;
  };

  const calculateDailyCost = () => {
    if (!settings) return 0;

    const totalDailyKwh = appliances.reduce((sum, app) => {
      return sum + (app.wattage * app.daily_hours) / 1000;
    }, 0);

    return totalDailyKwh * settings.electricity_rate;
  };

  const monthlyBill = calculateMonthlyBill();
  const dailyCost = calculateDailyCost();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Loading...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Dashboard</h2>
        <p className="text-gray-400">Overview of your electricity usage and costs</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
          <div className="flex items-center justify-between mb-4">
            <div className="text-gray-400 text-sm font-medium">Monthly Estimate</div>
            <DollarSign className="text-[#4fc3f7]" size={20} />
          </div>
          <div className="text-3xl font-bold text-white">
            {settings?.currency}{monthlyBill.toFixed(2)}
          </div>
          <div className="text-gray-500 text-sm mt-2">
            Based on {appliances.length} appliances
          </div>
        </div>

        <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
          <div className="flex items-center justify-between mb-4">
            <div className="text-gray-400 text-sm font-medium">Daily Cost</div>
            <TrendingUp className="text-[#7c6af7]" size={20} />
          </div>
          <div className="text-3xl font-bold text-white">
            {settings?.currency}{dailyCost.toFixed(2)}
          </div>
          <div className="text-gray-500 text-sm mt-2">
            {(dailyCost * 30).toFixed(1)} kWh/month
          </div>
        </div>

        <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
          <div className="flex items-center justify-between mb-4">
            <div className="text-gray-400 text-sm font-medium">Weather Impact</div>
            <Cloud className="text-[#4fc3f7]" size={20} />
          </div>
          <div className="text-3xl font-bold text-white">
            {settings?.currency}0.00
          </div>
          <div className="text-gray-500 text-sm mt-2">
            Check Weather tab
          </div>
        </div>

        <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
          <div className="flex items-center justify-between mb-4">
            <div className="text-gray-400 text-sm font-medium">Active Appliances</div>
            <Zap className="text-[#7c6af7]" size={20} />
          </div>
          <div className="text-3xl font-bold text-white">
            {appliances.filter(a => a.daily_hours > 0).length}
          </div>
          <div className="text-gray-500 text-sm mt-2">
            of {appliances.length} total
          </div>
        </div>
      </div>

      <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
        <h3 className="text-xl font-bold text-white mb-4">Top Energy Consumers</h3>
        {appliances.length === 0 ? (
          <p className="text-gray-400">No appliances added yet. Add some in the Appliances page!</p>
        ) : (
          <div className="space-y-3">
            {appliances
              .sort((a, b) => (b.wattage * b.daily_hours) - (a.wattage * a.daily_hours))
              .slice(0, 5)
              .map((appliance) => {
                const dailyKwh = (appliance.wattage * appliance.daily_hours) / 1000;
                const monthlyCost = dailyKwh * 30 * (settings?.electricity_rate || 0.12);
                const maxDailyKwh = appliances.reduce((max, app) => {
                  const kwh = (app.wattage * app.daily_hours) / 1000;
                  return kwh > max ? kwh : max;
                }, 0);
                const percentage = maxDailyKwh > 0 ? (dailyKwh / maxDailyKwh) * 100 : 0;

                return (
                  <div key={appliance.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-white font-medium">{appliance.name}</span>
                      <span className="text-[#4fc3f7] font-semibold">
                        {settings?.currency}{monthlyCost.toFixed(2)}/mo
                      </span>
                    </div>
                    <div className="w-full bg-[#060d1f] rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-[#4fc3f7] to-[#7c6af7] h-2 rounded-full transition-all"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <div className="text-sm text-gray-500">
                      {appliance.wattage}W × {appliance.daily_hours}h/day = {dailyKwh.toFixed(2)} kWh/day
                    </div>
                  </div>
                );
              })}
          </div>
        )}
      </div>
    </div>
  );
}
