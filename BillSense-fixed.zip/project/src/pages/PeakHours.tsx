import { useEffect, useState } from 'react';
import { Clock, Bell, TrendingUp, TrendingDown } from 'lucide-react';
import type { UserSettings } from '../lib/supabase';

interface PeakHoursProps {
  settings: UserSettings | null;
}

interface HourData {
  hour: number;
  label: string;
  rate: number;
  type: 'off-peak' | 'mid-peak' | 'peak';
}

export function PeakHours({ settings }: PeakHoursProps) {
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  useEffect(() => {
    if ('Notification' in window) {
      setNotificationsEnabled(Notification.permission === 'granted');
    }
  }, []);

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      setNotificationsEnabled(permission === 'granted');

      if (permission === 'granted') {
        new Notification('BillSense Notifications Enabled', {
          body: 'You will receive alerts about peak electricity hours',
          icon: '/vite.svg'
        });
      }
    }
  };

  const baseRate = settings?.electricity_rate || 0.12;

  const hourlyRates: HourData[] = Array.from({ length: 24 }, (_, i) => {
    let type: 'off-peak' | 'mid-peak' | 'peak';
    let multiplier: number;

    if (i >= 0 && i < 6) {
      type = 'off-peak';
      multiplier = 0.7;
    } else if ((i >= 6 && i < 9) || (i >= 21 && i < 24)) {
      type = 'mid-peak';
      multiplier = 1.0;
    } else if (i >= 14 && i < 19) {
      type = 'peak';
      multiplier = 1.5;
    } else {
      type = 'mid-peak';
      multiplier = 1.0;
    }

    const hour12 = i === 0 ? 12 : i > 12 ? i - 12 : i;
    const period = i < 12 ? 'AM' : 'PM';

    return {
      hour: i,
      label: `${hour12}:00 ${period}`,
      rate: baseRate * multiplier,
      type
    };
  });

  const offPeakHours = hourlyRates.filter(h => h.type === 'off-peak');
  const peakHours = hourlyRates.filter(h => h.type === 'peak');

  const cheapestRate = Math.min(...hourlyRates.map(h => h.rate));
  const expensiveRate = Math.max(...hourlyRates.map(h => h.rate));

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Peak Hour Alerts</h2>
        <p className="text-gray-400">Optimize your usage based on electricity rates</p>
      </div>

      <div className="bg-gradient-to-br from-[#0a1628] to-[#0f1f38] p-6 rounded-xl border border-gray-800">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Bell className="text-[#4fc3f7]" />
            Push Notifications
          </h3>
          {notificationsEnabled ? (
            <span className="text-green-500 text-sm font-medium px-3 py-1 bg-green-500/10 rounded-full">
              Enabled
            </span>
          ) : (
            <button
              onClick={requestNotificationPermission}
              className="bg-[#4fc3f7] text-white px-4 py-2 rounded-lg font-semibold hover:bg-[#3fb3e7] transition-colors text-sm"
            >
              Enable Notifications
            </button>
          )}
        </div>
        <p className="text-gray-400 text-sm">
          {notificationsEnabled
            ? 'You will receive alerts before peak hours begin'
            : 'Enable notifications to get alerts about peak electricity hours'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-green-500/10 rounded-lg">
              <TrendingDown className="text-green-500" size={24} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Cheapest Hours</h3>
              <p className="text-sm text-gray-400">Off-Peak (12 AM - 6 AM)</p>
            </div>
          </div>
          <div className="text-3xl font-bold text-green-500 mb-2">
            {settings?.currency}{cheapestRate.toFixed(3)}/kWh
          </div>
          <p className="text-gray-400 text-sm">
            Save up to {((1 - cheapestRate / expensiveRate) * 100).toFixed(0)}% by using appliances during these hours
          </p>
        </div>

        <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-red-500/10 rounded-lg">
              <TrendingUp className="text-red-500" size={24} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Most Expensive Hours</h3>
              <p className="text-sm text-gray-400">Peak (2 PM - 7 PM)</p>
            </div>
          </div>
          <div className="text-3xl font-bold text-red-500 mb-2">
            {settings?.currency}{expensiveRate.toFixed(3)}/kWh
          </div>
          <p className="text-gray-400 text-sm">
            Avoid using high-power appliances during peak hours to save money
          </p>
        </div>
      </div>

      <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Clock className="text-[#7c6af7]" />
          24-Hour Rate Schedule
        </h3>

        <div className="space-y-2">
          {hourlyRates.map((hour) => {
            const width = (hour.rate / expensiveRate) * 100;
            const colors = {
              'off-peak': 'from-green-500 to-green-600',
              'mid-peak': 'from-[#4fc3f7] to-[#3fb3e7]',
              'peak': 'from-red-500 to-red-600'
            };

            return (
              <div key={hour.hour} className="flex items-center gap-4">
                <div className="w-20 text-sm text-gray-400 font-medium">
                  {hour.label}
                </div>
                <div className="flex-1 bg-[#060d1f] rounded-full h-8 relative overflow-hidden">
                  <div
                    className={`h-full bg-gradient-to-r ${colors[hour.type]} transition-all`}
                    style={{ width: `${width}%` }}
                  />
                  <div className="absolute inset-0 flex items-center justify-between px-4">
                    <span className="text-xs font-semibold text-white capitalize">
                      {hour.type}
                    </span>
                    <span className="text-sm font-bold text-white">
                      {settings?.currency}{hour.rate.toFixed(3)}/kWh
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
        <h3 className="text-xl font-bold text-white mb-4">Money-Saving Tips</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-[#060d1f] p-4 rounded-lg">
            <div className="text-green-500 font-semibold mb-2">✓ Do During Off-Peak</div>
            <ul className="text-sm text-gray-400 space-y-1">
              <li>• Run dishwasher and laundry</li>
              <li>• Charge electric vehicles</li>
              <li>• Use pool pumps</li>
              <li>• Run water heaters</li>
            </ul>
          </div>
          <div className="bg-[#060d1f] p-4 rounded-lg">
            <div className="text-red-500 font-semibold mb-2">✗ Avoid During Peak</div>
            <ul className="text-sm text-gray-400 space-y-1">
              <li>• Heavy appliance use</li>
              <li>• Electric heating/cooling</li>
              <li>• Large electronics</li>
              <li>• Non-essential devices</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
