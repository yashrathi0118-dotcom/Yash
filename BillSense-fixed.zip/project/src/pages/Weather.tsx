import { useEffect, useState } from 'react';
import { Cloud, Wind, Thermometer, Droplets } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Appliance, UserSettings } from '../lib/supabase';

interface WeatherProps {
  userId: string;
  settings: UserSettings | null;
}

interface WeatherData {
  temp: number;
  feels_like: number;
  humidity: number;
  description: string;
  wind_speed: number;
  weatherCode: number;
}

interface ForecastDay {
  date: string;
  temp_max: number;
  temp_min: number;
  description: string;
  weatherCode: number;
}

const getWeatherEmoji = (code: number) => {
  if (code === 0) return '☀️';
  if (code <= 2) return '⛅';
  if (code <= 48) return '🌫️';
  if (code <= 67) return '🌧️';
  if (code <= 77) return '❄️';
  if (code <= 82) return '🌦️';
  if (code <= 99) return '⛈️';
  return '🌤️';
};

const getWeatherDescription = (code: number) => {
  if (code === 0) return 'Clear Sky';
  if (code <= 2) return 'Partly Cloudy';
  if (code <= 48) return 'Foggy';
  if (code <= 55) return 'Drizzle';
  if (code <= 67) return 'Rainy';
  if (code <= 77) return 'Snowy';
  if (code <= 82) return 'Rain Showers';
  if (code <= 99) return 'Thunderstorm';
  return 'Cloudy';
};

export function Weather({ userId, settings }: WeatherProps) {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [forecast, setForecast] = useState<ForecastDay[]>([]);
  const [loading, setLoading] = useState(true);
  const [appliances, setAppliances] = useState<Appliance[]>([]);
  const [locationName, setLocationName] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    loadAppliances();
    loadWeather();
  }, [settings]);

  const loadAppliances = async () => {
    const { data, error } = await supabase
      .from('appliances')
      .select('*')
      .eq('user_id', userId);
    if (!error && data) setAppliances(data);
  };

  const loadWeather = async () => {
    setLoading(true);
    setError('');
    try {
      const location = settings?.location || 'Karachi';

      // Step 1: Get coordinates from city name
      const geoRes = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(location)}&count=1&language=en&format=json`
      );
      const geoData = await geoRes.json();

      if (!geoData.results || geoData.results.length === 0) {
        setError('City not found. Please update your location in Settings.');
        setLoading(false);
        return;
      }

      const { latitude, longitude, name, country } = geoData.results[0];
      setLocationName(`${name}, ${country}`);

      // Step 2: Get weather forecast
      const weatherRes = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code&daily=temperature_2m_max,temperature_2m_min,weather_code&timezone=auto&forecast_days=7`
      );
      const weatherJson = await weatherRes.json();

      const current = weatherJson.current;
      setWeatherData({
        temp: Math.round(current.temperature_2m),
        feels_like: Math.round(current.apparent_temperature),
        humidity: current.relative_humidity_2m,
        wind_speed: Math.round(current.wind_speed_10m),
        description: getWeatherDescription(current.weather_code),
        weatherCode: current.weather_code,
      });

      const daily = weatherJson.daily;
      const days: ForecastDay[] = daily.time.map((date: string, i: number) => ({
        date: new Date(date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
        temp_max: Math.round(daily.temperature_2m_max[i]),
        temp_min: Math.round(daily.temperature_2m_min[i]),
        weatherCode: daily.weather_code[i],
        description: getWeatherDescription(daily.weather_code[i]),
      }));
      setForecast(days);

    } catch (err) {
      setError('Failed to load weather. Please check your internet connection.');
    }
    setLoading(false);
  };

  const calculateWeatherImpact = () => {
    if (!weatherData || !settings) return { heating: 0, cooling: 0, total: 0 };

    const coolingAppliances = appliances.filter(a =>
      a.name.toLowerCase().includes('ac') ||
      a.name.toLowerCase().includes('air') ||
      a.name.toLowerCase().includes('cool') ||
      a.name.toLowerCase().includes('fan')
    );
    const heatingAppliances = appliances.filter(a =>
      a.name.toLowerCase().includes('heat') ||
      a.name.toLowerCase().includes('furnace') ||
      a.name.toLowerCase().includes('geyser') ||
      a.name.toLowerCase().includes('heater')
    );

    let coolingImpact = 0;
    let heatingImpact = 0;

    if (weatherData.temp > 30) {
      const tempDiff = weatherData.temp - 30;
      const multiplier = 1 + tempDiff * 0.015;
      coolingImpact = coolingAppliances.reduce((sum, app) => {
        const dailyKwh = (app.wattage * app.daily_hours * multiplier) / 1000;
        return sum + dailyKwh * 7 * settings.electricity_rate;
      }, 0);
    }

    if (weatherData.temp < 15) {
      const tempDiff = 15 - weatherData.temp;
      const multiplier = 1 + tempDiff * 0.02;
      heatingImpact = heatingAppliances.reduce((sum, app) => {
        const dailyKwh = (app.wattage * app.daily_hours * multiplier) / 1000;
        return sum + dailyKwh * 7 * settings.electricity_rate;
      }, 0);
    }

    return { heating: heatingImpact, cooling: coolingImpact, total: heatingImpact + coolingImpact };
  };

  const impact = calculateWeatherImpact();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Loading weather data...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-6">
        <h2 className="text-3xl font-bold text-white mb-2">Weather Bill Predictor</h2>
        <div className="bg-[#0a1628] p-8 rounded-xl border border-red-800 text-center">
          <Cloud className="text-red-400 mx-auto mb-4" size={48} />
          <p className="text-red-400 font-semibold">{error}</p>
          <button
            onClick={loadWeather}
            className="mt-4 bg-[#4fc3f7] text-white px-6 py-2 rounded-lg font-semibold hover:bg-[#3fb3e7] transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">Weather Bill Predictor</h2>
        <p className="text-gray-400">Powered by Open-Meteo — No API key needed ✅</p>
      </div>

      {weatherData && (
        <>
          <div className="bg-gradient-to-br from-[#0a1628] to-[#0f1f38] p-8 rounded-xl border border-gray-800">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-2xl font-bold text-white mb-2">{locationName}</h3>
                <p className="text-gray-400 capitalize mb-4">{weatherData.description}</p>
                <div className="flex items-end gap-3">
                  <span className="text-6xl font-bold text-white">{weatherData.temp}°C</span>
                  <span className="text-xl text-gray-400 mb-2">Feels like {weatherData.feels_like}°C</span>
                </div>
              </div>
              <div className="text-7xl">{getWeatherEmoji(weatherData.weatherCode)}</div>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-6">
              <div className="flex items-center gap-3 text-gray-400">
                <Droplets className="text-[#4fc3f7]" size={20} />
                <div>
                  <div className="text-sm">Humidity</div>
                  <div className="text-white font-semibold">{weatherData.humidity}%</div>
                </div>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <Wind className="text-[#4fc3f7]" size={20} />
                <div>
                  <div className="text-sm">Wind Speed</div>
                  <div className="text-white font-semibold">{weatherData.wind_speed} km/h</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Thermometer className="text-[#7c6af7]" />
              Weather Impact on Your Bill (This Week)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-[#060d1f] p-4 rounded-lg">
                <div className="text-gray-400 text-sm mb-2">Heating Impact</div>
                <div className="text-2xl font-bold text-white">{settings?.currency}{impact.heating.toFixed(2)}</div>
                <div className="text-xs text-gray-500 mt-1">
                  {weatherData.temp < 15 ? 'Cold weather — heater running more' : 'Minimal heating needed'}
                </div>
              </div>
              <div className="bg-[#060d1f] p-4 rounded-lg">
                <div className="text-gray-400 text-sm mb-2">Cooling Impact</div>
                <div className="text-2xl font-bold text-white">{settings?.currency}{impact.cooling.toFixed(2)}</div>
                <div className="text-xs text-gray-500 mt-1">
                  {weatherData.temp > 30 ? 'Hot weather — AC running more' : 'Minimal cooling needed'}
                </div>
              </div>
              <div className="bg-gradient-to-br from-[#4fc3f7] to-[#7c6af7] p-4 rounded-lg">
                <div className="text-white text-sm mb-2">Total Weather Impact</div>
                <div className="text-2xl font-bold text-white">{settings?.currency}{impact.total.toFixed(2)}</div>
                <div className="text-xs text-white/80 mt-1">Extra cost this week due to weather</div>
              </div>
            </div>
          </div>

          <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
            <h3 className="text-xl font-bold text-white mb-4">7-Day Forecast</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
              {forecast.map((day, index) => (
                <div key={index} className="bg-[#060d1f] p-4 rounded-lg text-center">
                  <div className="text-gray-400 text-xs mb-2">{day.date}</div>
                  <div className="text-3xl mb-2">{getWeatherEmoji(day.weatherCode)}</div>
                  <div className="text-white font-semibold text-sm">{day.temp_max}° / {day.temp_min}°</div>
                  <div className="text-xs text-gray-500 mt-1">{day.description}</div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
