import { useEffect, useState } from 'react';
import { Plus, Trash2, CreditCard as Edit2, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Appliance, UserSettings } from '../lib/supabase';

interface AppliancesProps {
  userId: string;
  settings: UserSettings | null;
}

export function Appliances({ userId, settings }: AppliancesProps) {
  const [appliances, setAppliances] = useState<Appliance[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    wattage: '',
    daily_hours: ''
  });

  useEffect(() => {
    loadAppliances();
  }, [userId]);

  const loadAppliances = async () => {
    const { data, error } = await supabase
      .from('appliances')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading appliances:', error);
    } else {
      setAppliances(data || []);
    }
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const applianceData = {
      user_id: userId,
      name: formData.name,
      wattage: parseInt(formData.wattage),
      daily_hours: parseFloat(formData.daily_hours)
    };

    if (editingId) {
      const { error } = await supabase
        .from('appliances')
        .update(applianceData)
        .eq('id', editingId);

      if (error) {
        console.error('Error updating appliance:', error);
        return;
      }
    } else {
      const { error } = await supabase
        .from('appliances')
        .insert(applianceData);

      if (error) {
        console.error('Error adding appliance:', error);
        return;
      }
    }

    setFormData({ name: '', wattage: '', daily_hours: '' });
    setShowForm(false);
    setEditingId(null);
    loadAppliances();
  };

  const handleEdit = (appliance: Appliance) => {
    setFormData({
      name: appliance.name,
      wattage: appliance.wattage.toString(),
      daily_hours: appliance.daily_hours.toString()
    });
    setEditingId(appliance.id);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this appliance?')) return;

    const { error } = await supabase
      .from('appliances')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Error deleting appliance:', error);
    } else {
      loadAppliances();
    }
  };

  const calculateCost = (wattage: number, hours: number) => {
    const dailyKwh = (wattage * hours) / 1000;
    const monthlyKwh = dailyKwh * 30;
    return monthlyKwh * (settings?.electricity_rate || 0.12);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Loading...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Appliances</h2>
          <p className="text-gray-400">Manage your home appliances and their usage</p>
        </div>
        <button
          onClick={() => {
            setFormData({ name: '', wattage: '', daily_hours: '' });
            setEditingId(null);
            setShowForm(true);
          }}
          className="bg-[#4fc3f7] text-white px-4 py-2 rounded-lg font-semibold hover:bg-[#3fb3e7] transition-colors flex items-center gap-2"
        >
          <Plus size={20} />
          Add Appliance
        </button>
      </div>

      {showForm && (
        <div className="bg-[#0a1628] p-6 rounded-xl border border-gray-800">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-white">
              {editingId ? 'Edit Appliance' : 'Add New Appliance'}
            </h3>
            <button
              onClick={() => {
                setShowForm(false);
                setEditingId(null);
              }}
              className="text-gray-400 hover:text-white"
            >
              <X size={20} />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Appliance Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 bg-[#060d1f] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#4fc3f7]"
                placeholder="e.g., Refrigerator, Air Conditioner"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Power (Watts)
                </label>
                <input
                  type="number"
                  value={formData.wattage}
                  onChange={(e) => setFormData({ ...formData, wattage: e.target.value })}
                  className="w-full px-4 py-2 bg-[#060d1f] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#4fc3f7]"
                  placeholder="e.g., 1500"
                  required
                  min="1"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Daily Hours
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={formData.daily_hours}
                  onChange={(e) => setFormData({ ...formData, daily_hours: e.target.value })}
                  className="w-full px-4 py-2 bg-[#060d1f] border border-gray-700 rounded-lg text-white focus:outline-none focus:border-[#4fc3f7]"
                  placeholder="e.g., 8"
                  required
                  min="0"
                  max="24"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-[#4fc3f7] text-white py-2 rounded-lg font-semibold hover:bg-[#3fb3e7] transition-colors"
            >
              {editingId ? 'Update Appliance' : 'Add Appliance'}
            </button>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {appliances.length === 0 ? (
          <div className="col-span-full text-center py-12 text-gray-400">
            No appliances added yet. Click "Add Appliance" to get started!
          </div>
        ) : (
          appliances.map((appliance) => {
            const monthlyCost = calculateCost(appliance.wattage, appliance.daily_hours);
            const dailyKwh = (appliance.wattage * appliance.daily_hours) / 1000;

            return (
              <div
                key={appliance.id}
                className="bg-[#0a1628] p-6 rounded-xl border border-gray-800 hover:border-[#4fc3f7] transition-colors"
              >
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-lg font-bold text-white">{appliance.name}</h3>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleEdit(appliance)}
                      className="text-gray-400 hover:text-[#4fc3f7] transition-colors"
                    >
                      <Edit2 size={18} />
                    </button>
                    <button
                      onClick={() => handleDelete(appliance.id)}
                      className="text-gray-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-gray-400">
                    <span>Power:</span>
                    <span className="text-white font-medium">{appliance.wattage}W</span>
                  </div>
                  <div className="flex justify-between text-gray-400">
                    <span>Daily Usage:</span>
                    <span className="text-white font-medium">{appliance.daily_hours}h</span>
                  </div>
                  <div className="flex justify-between text-gray-400">
                    <span>Daily Cost:</span>
                    <span className="text-white font-medium">
                      {settings?.currency}{(monthlyCost / 30).toFixed(2)}
                    </span>
                  </div>
                  <div className="pt-2 border-t border-gray-700">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Monthly Cost:</span>
                      <span className="text-[#4fc3f7] font-bold text-lg">
                        {settings?.currency}{monthlyCost.toFixed(2)}
                      </span>
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 pt-1">
                    {dailyKwh.toFixed(2)} kWh/day • {(dailyKwh * 30).toFixed(1)} kWh/month
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
