import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Appliance {
  id: string;
  user_id: string;
  name: string;
  wattage: number;
  daily_hours: number;
  created_at: string;
  updated_at: string;
}

export interface FamilyMember {
  id: string;
  user_id: string;
  name: string;
  color: string;
  created_at: string;
}

export interface ApplianceAssignment {
  id: string;
  appliance_id: string;
  member_id: string;
  percentage: number;
  created_at: string;
}

export interface UserSettings {
  id: string;
  user_id: string;
  electricity_rate: number;
  location: string;
  currency: string;
  created_at: string;
  updated_at: string;
}
