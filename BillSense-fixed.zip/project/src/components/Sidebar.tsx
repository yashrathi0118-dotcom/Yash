import { Home, Zap, Cloud, Clock, Users, Settings, LogOut } from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onSignOut: () => void;
}

export function Sidebar({ currentPage, onNavigate, onSignOut }: SidebarProps) {
  const navItems = [
    { id: 'dashboard', icon: Home, label: 'Dashboard' },
    { id: 'appliances', icon: Zap, label: 'Appliances' },
    { id: 'weather', icon: Cloud, label: 'Weather Predictor' },
    { id: 'peak-hours', icon: Clock, label: 'Peak Hours' },
    { id: 'family', icon: Users, label: 'Family Splitter' },
    { id: 'settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <div className="w-64 bg-[#0a1628] h-screen fixed left-0 top-0 flex flex-col border-r border-gray-800">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <Zap className="text-[#4fc3f7]" />
          BillSense
        </h1>
      </div>

      <nav className="flex-1 px-3">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg mb-1 transition-all ${
                isActive
                  ? 'bg-[#4fc3f7] text-white'
                  : 'text-gray-400 hover:bg-[#0f1f38] hover:text-white'
              }`}
            >
              <Icon size={20} />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-3">
        <button
          onClick={onSignOut}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-gray-400 hover:bg-[#0f1f38] hover:text-white transition-all"
        >
          <LogOut size={20} />
          <span className="font-medium">Sign Out</span>
        </button>
      </div>
    </div>
  );
}
